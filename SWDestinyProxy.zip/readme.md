I made this proxy generator for people who want to try out cards from SW Destiny before buying them.

#INSTRUCTIONS:
Just [download](http://ossianboren.com/SWDestinyProxy/SWDestinyProxy.zip) and unzip, or [visit the web version](http://ossianboren.com/SWDestinyProxy/) then add cards by their ID number. Then print from your browser (they should be neatly gridded for cutting).

#CUSTOM DATABASE
If you downloaded the zip, you can provide your own database! Just get the cards.json from [here](http://swdestinydb.com/api/public/cards/), put it in the SWDestinyProxy folder, then change cards.json however you like! (Translations, custom cards, etc)

Trust in the force!

made by [@ossianboren](https://twitter.com/ossianboren)